-- itau.permission definition
CREATE TABLE `permission` (
	`id` bigint NOT NULL AUTO_INCREMENT,
	`description` varchar(255) DEFAULT NULL
) ENGINE = InnoDB;
