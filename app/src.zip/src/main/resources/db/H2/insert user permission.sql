INSERT INTO itau.user_permission (id_user, id_permission)
VALUES (1, 1);
INSERT INTO itau.user_permission (id_user, id_permission)
VALUES (1, 2);
INSERT INTO itau.user_permission (id_user, id_permission)
VALUES (1, 3);
