INSERT INTO USERS (id, user_name, full_name, password, account_non_expired
	, account_non_locked, credentials_non_expired, enabled)
VALUES (1, 'teste', 'Teste Adm', '19bbf735b27066f2f145e602624e1b24a3fbc54cd5dfd3143fc5feea6bdee9e139ca7332d4806b9f', 1
	, 1, 1, 1);
