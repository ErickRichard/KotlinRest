INSERT INTO USER_PERMISSION  (id_user, id_permission)
VALUES (1, 1);
INSERT INTO USER_PERMISSION (id_user, id_permission)
VALUES (1, 2);
INSERT INTO USER_PERMISSION (id_user, id_permission)
VALUES (1, 3);
