package com.eks.kotlineks.constant

enum class StatusType(val value: String) {
    All("TODS"),
    ACTIVE("ATIV"),
    APPROVED("APRA"),
    CANCELED("CNCL"),
    EXPIRED("EXRO"),
    PENDING("PDNT"),
    REPROVED("RPRD");
}