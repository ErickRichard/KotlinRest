package com.eks.kotlineks.interfaces

interface EnumConverter {
    fun getValue(): String?
    fun getDescription(): String?
}