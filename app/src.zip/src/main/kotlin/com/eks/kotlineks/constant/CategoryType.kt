package com.eks.kotlineks.constant

enum class CategoryType (val value: String) {
    PRODUCT("PROD"),
    CREDIT_INVOICE("CRFT");
}