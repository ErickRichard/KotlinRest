package com.eks.kotlineks.data.vo.v1.request


import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonPropertyOrder
import com.github.dozermapper.core.Mapping
import org.springframework.hateoas.RepresentationModel
import java.math.BigDecimal
import java.util.*

@JsonPropertyOrder(
    "ruleId",
    "name",
    "createBy",
    "cpp",
    "initialDate",
    "endDate",
    "categoryId",
)
data class RuleRequestVO(
    @Mapping("ruleId")
    @field:JsonProperty("ruleId")
    var key: Long = 0,
    var name: String = "",
    var createBy: String = "",
    var cpp: BigDecimal = BigDecimal.ZERO,
    var initialDate: Date? = null,
    var endDate: Date? = null,
    var categoryId: Long = 0,
) : RepresentationModel<RuleRequestVO>()