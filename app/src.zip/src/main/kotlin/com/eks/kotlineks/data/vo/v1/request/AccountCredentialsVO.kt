package com.eks.kotlineks.data.vo.v1.request

data class AccountCredentialsVO(
    val username: String? = null,
    val password: String? = null,
)
