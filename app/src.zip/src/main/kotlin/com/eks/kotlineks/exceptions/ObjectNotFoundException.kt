package com.eks.kotlineks.exceptions

class ObjectNotFoundException(message:String): Exception(message)