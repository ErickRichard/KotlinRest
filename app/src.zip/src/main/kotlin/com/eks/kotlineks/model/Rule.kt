package com.eks.kotlineks.model

import java.math.BigDecimal
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "regra")
class Rule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "regra_id")
    var ruleId: Long = 0

    @Column(name = "nome")
    var name: String = ""

    @Column(name = "criado_Por")
    var createBy: String = ""

    @Column(name = "data_Criacao")
    var dataCreation: Date? = null

    @Column(name = "cpp")
    var cpp: BigDecimal = BigDecimal.ZERO

    @Column(name = "aprovado_Por")
    var approvedBy: String = ""

    @Column(name = "data_aprovacao")
    var approvalDate: Date? = null

    @Column(name = "data_Inicio_Vigencia")
    var initialDate: Date? = null

    @Column(name = "data_Fim_Vigencia")
    var endDate: Date? = null

    @ManyToOne
    @JoinColumn(name = "status_id", referencedColumnName = "status_id")
    lateinit var statusRule: StatusRule

    @ManyToOne
    @JoinColumn(name = "categoria_id", referencedColumnName = "categoria_id")
    lateinit var categoryRule: CategoryRule

}

