package com.eks.kotlineks.repository

import com.eks.kotlineks.model.StatusRule
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository
import java.util.*

@Repository
interface StatusRepository : JpaRepository<StatusRule, Long?> {

    @Query("SELECT s FROM StatusRule s WHERE s.name =:name")
    fun findStatusByName(@Param("name") status: String): Optional<StatusRule>

}