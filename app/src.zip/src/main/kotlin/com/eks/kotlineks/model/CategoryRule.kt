package com.eks.kotlineks.model

import javax.persistence.*

@Entity
@Table(name = "categoria")
class CategoryRule(

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "categoria_id")
    var categoryId: Long = 0,

    @Column(name = "nome")
    var name: String? = null,

    @Column(name = "descricao")
    var description: String? = null

)