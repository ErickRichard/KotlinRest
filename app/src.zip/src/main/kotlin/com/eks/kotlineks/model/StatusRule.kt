package com.eks.kotlineks.model

import javax.persistence.*

@Entity
@Table(name = "status")
class StatusRule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "status_id")
    var statusId: Long = 0

    @Column(name = "nome")
    var name: String? = null

    @Column(name = "descricao")
    var description: String? = null
}