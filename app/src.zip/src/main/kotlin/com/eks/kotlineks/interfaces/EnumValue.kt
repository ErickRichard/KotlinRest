package com.eks.kotlineks.interfaces

interface EnumValue {
    val value: String?
    val description: String?
}