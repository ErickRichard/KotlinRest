package com.eks.kotlineks.data.vo.v1.response

import com.fasterxml.jackson.annotation.JsonPropertyOrder

@JsonPropertyOrder(
    "statusId",
    "name",
    "description"
)
data class StatusRuleResponseVO(
    var statusId: Long = 0,
    var name: String = "",
    var description: String = ""
)