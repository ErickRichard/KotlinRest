package com.eks.kotlineks.data.vo.v1.response

import com.fasterxml.jackson.annotation.JsonPropertyOrder

@JsonPropertyOrder(
    "categoryId",
    "name",
    "description"
)
data class CategoryRuleResponseVO(
    var categoryId: Long = 0,
    var name: String = "",
    var description: String = ""
)